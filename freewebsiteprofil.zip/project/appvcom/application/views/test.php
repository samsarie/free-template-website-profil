<!DOCTYPE html>
<html>
<head>
	<title><?php $brg->plu_id; ?></title>
</head>
<body>

</body>
</html>